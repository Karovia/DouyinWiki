import { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ImportForm from './components/ImportForm';
import ProcessingCard from './components/ProcessingCard';
import WikiGrid from './components/WikiGrid';
import { WikiItem, TaskStatus } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

const MOCK_WIKIS: WikiItem[] = [
  {
    id: '1',
    title: 'Zero Trust Architecture Explained',
    author: 'TechFlow',
    timeAgo: '2 days ago',
    duration: '12:45',
    summary: 'A deep dive into how modern enterprise networks are abandoning the traditional perimeter model in favor of verifying every single request.',
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '2',
    title: 'LLMs: The Next Shift in UI Design',
    author: 'DesignOps',
    timeAgo: '1 week ago',
    duration: '08:20',
    summary: 'Exploring the transition from graphical user interfaces to conversational and intent-based interactions powered by Large Language Models.',
    imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '3',
    title: 'Advanced System Architecture Patterns',
    author: 'DevInsights',
    timeAgo: '3 weeks ago',
    duration: '45:12',
    summary: 'A comprehensive overview of building scalable, distributed systems. We look at event-driven architectures, CQRS, and maintaining consistency.',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800'
  }
];

const RECENT_IMPORTS = [
  { id: '1', title: '如何高效使用抖音 Wiki 进行知识管理', date: '2024-05-20 14:30', status: 'Completed' },
  { id: '2', title: 'AI 辅助阅读的长视频拆解技巧', date: '2024-05-19 10:15', status: 'Completed' },
];

export default function App() {
  const [currentView, setCurrentView] = useState<'import' | 'list'>('import');
  const [task, setTask] = useState<TaskStatus | null>(null);
  const [wikis, setWikis] = useState<WikiItem[]>(MOCK_WIKIS);

  const handleImport = (url: string) => {
    const taskId = `DY-${Math.floor(Math.random() * 9000) + 1000}`;
    setTask({
      id: taskId,
      progress: 0,
      status: 'processing',
      message: 'Initialing task...'
    });
  };

  useEffect(() => {
    if (task && task.status === 'processing') {
      const timer = setInterval(() => {
        setTask(prev => {
          if (!prev) return null;
          const nextProgress = prev.progress + Math.floor(Math.random() * 10) + 5;
          if (nextProgress >= 100) {
            clearInterval(timer);
            return { ...prev, progress: 100, status: 'completed', message: 'Ready to view' };
          }
          
          let message = 'Parsing metadata...';
          if (nextProgress > 30) message = 'Extracting audio transcript...';
          if (nextProgress > 60) message = 'Generating structures knowledge...';
          if (nextProgress > 85) message = 'Finalizing wiki page...';

          return { ...prev, progress: nextProgress, message };
        });
      }, 800);
      return () => clearInterval(timer);
    }
  }, [task?.status]);

  return (
    <div className="min-h-screen flex flex-col selection:bg-black selection:text-white">
      <Header currentView={currentView} onNavigate={setCurrentView} />
      
      <main className="flex-grow w-full px-6 md:px-12 max-w-[1200px] mx-auto py-12 md:py-20">
        <AnimatePresence mode="wait">
          {currentView === 'import' ? (
            <motion.div 
              key="import-view"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              className="space-y-16"
            >
              <ImportForm onImport={handleImport} isProcessing={!!task && task.status === 'processing'} />
              
              {task && <ProcessingCard task={task} />}

              {!task && (
                <div className="space-y-8 pt-20 max-w-[700px] mx-auto">
                  <h3 className="text-center text-[12px] font-bold text-text-secondary uppercase tracking-[0.2em]">最近导入</h3>
                  <div className="space-y-3">
                    {RECENT_IMPORTS.map((item) => (
                      <div key={item.id} className="card p-5 flex justify-between items-center hover:border-text-secondary transition-all cursor-pointer">
                        <div className="space-y-1">
                          <p className="text-[15px] font-bold text-text-primary">{item.title}</p>
                          <p className="text-[12px] text-text-secondary">{item.date}</p>
                        </div>
                        <div className="flex items-center gap-2 text-[13px] text-text-secondary font-medium">
                          <CheckCircle2 size={16} className="text-green-500" />
                          {item.status}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="list-view"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <WikiGrid items={wikis} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}
