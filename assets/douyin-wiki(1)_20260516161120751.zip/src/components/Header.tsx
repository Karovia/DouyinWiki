import { motion } from 'motion/react';
import { Play } from 'lucide-react';

interface HeaderProps {
  currentView: 'import' | 'list';
  onNavigate: (view: 'import' | 'list') => void;
}

export default function Header({ currentView, onNavigate }: HeaderProps) {
  return (
    <header className="bg-surface w-full sticky top-0 z-50 transition-all duration-300">
      <div className="flex justify-between items-center w-full px-8 md:px-12 py-8 max-w-[1200px] mx-auto">
        <div 
          className="text-[18px] font-bold text-text-primary flex items-center gap-3 cursor-pointer"
          onClick={() => onNavigate('import')}
        >
          <div className="w-8 h-8 bg-text-primary rounded-md flex items-center justify-center text-white">
            <Play size={16} fill="white" />
          </div>
          Douyin Wiki
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-[15px]">
          <button 
            className={`transition-colors duration-200 ${currentView === 'import' ? 'text-text-primary font-semibold' : 'text-text-secondary hover:text-text-primary'}`}
            onClick={() => onNavigate('import')}
          >
            Import Video
          </button>
          <button 
            className={`transition-colors duration-200 ${currentView === 'list' ? 'text-text-primary font-semibold' : 'text-text-secondary hover:text-text-primary'}`}
            onClick={() => onNavigate('list')}
          >
            Wiki List
          </button>
        </nav>

        <div className="flex items-center gap-4">
          <span className="text-[13px] text-text-secondary font-medium hidden sm:block">ENG</span>
          <button className="text-[13px] text-text-primary font-semibold">Log In</button>
        </div>
      </div>
    </header>
  );
}
