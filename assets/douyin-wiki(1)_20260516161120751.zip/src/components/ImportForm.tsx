import { useState, FormEvent } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface ImportFormProps {
  onImport: (url: string) => void;
  isProcessing: boolean;
}

export default function ImportForm({ onImport, isProcessing }: ImportFormProps) {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onImport(url);
    }
  };

  return (
    <div className="flex flex-col items-center text-center space-y-12">
      <div className="space-y-4">
        <h1 className="text-[48px] font-bold tracking-tight text-text-primary leading-[1.2]">
          将视频变成知识
        </h1>
        <p className="text-text-secondary text-[16px]">
          粘贴抖音链接，让 AI 帮你提取结构化知识
        </p>
      </div>

      <form 
        onSubmit={handleSubmit}
        className="w-full max-w-[700px] relative group"
      >
        <input 
          type="text" 
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://v.douyin.com/..."
          disabled={isProcessing}
          className="w-full h-16 px-6 pr-40 bg-surface border border-border-subtle rounded-2xl text-[16px] focus:outline-none focus:border-text-primary transition-all shadow-sm group-hover:border-text-secondary disabled:opacity-50"
        />
        <button 
          type="submit"
          disabled={isProcessing || !url.trim()}
          className="absolute right-2 top-2 bottom-2 bg-accent text-white px-6 rounded-xl flex items-center gap-2 hover:bg-text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          开始提取
          <ArrowRight size={18} />
        </button>
      </form>
    </div>
  );
}
