import { WikiItem } from '../types';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

interface WikiGridProps {
  items: WikiItem[];
}

export default function WikiGrid({ items }: WikiGridProps) {
  return (
    <div className="space-y-12">
      <div className="flex items-center gap-4">
        <h1 className="text-[48px] font-bold tracking-tight text-text-primary">Wiki 列表</h1>
        <span className="px-4 py-1.5 bg-surface-container border border-border-subtle rounded-full text-[14px] font-medium">
          {items.length} 项
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {items.map((item, index) => (
          <motion.article 
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card p-6 flex flex-col group hover:border-text-secondary hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)] cursor-default"
          >
            <div className="relative aspect-[16/10] overflow-hidden rounded-xl bg-border-subtle mb-6">
              <img 
                src={item.imageUrl} 
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-md text-white text-[11px] font-medium">
                {item.duration}
              </div>
            </div>

            <div className="flex flex-col flex-grow space-y-3">
              <h2 className="text-[18px] font-bold leading-tight line-clamp-2 text-text-primary group-hover:text-black">
                {item.title}
              </h2>
              
              <div className="flex items-center gap-2 text-[13px] text-text-secondary">
                <span>{item.author}</span>
                <span>·</span>
                <span>{item.timeAgo}</span>
              </div>

              <p className="text-[14px] text-text-secondary leading-relaxed line-clamp-3 flex-grow">
                {item.summary}
              </p>

              <button className="flex items-center gap-2 text-[14px] font-bold text-text-primary hover:gap-3 transition-all mt-4">
                Read Wiki <ArrowRight size={16} />
              </button>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  );
}
